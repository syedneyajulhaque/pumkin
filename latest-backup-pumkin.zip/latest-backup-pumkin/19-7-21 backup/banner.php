  <section id="banner-bg">
         <div class="container">
            <div class="row">
               <div class="banner-box">
                  <ul>
                     <li><a class="activess" href="#">Dog Breeds</a></li>
                     <li><a href="#">Cat Breeds</a></li>
                  </ul>
                  <h1>Find your pawfect pooch.</h1>
                  <p>Search for a specific breed or use our fun filters to find a dog that fits your needs and lifestyle.</p>
                  <div id="facet" class="input-group">
                     <span class="qsearchlisting"><input type="text" id="search-breeds"  class="form-control" placeholder="Search by breed name"> <i class="fa fa-search" aria-hidden="true"></i></span>
							<ul class="my-list">
							<?php
							echo wp_list_pages( array(
							'title_li'    => '',
							) );
							?>
							</ul>
                  </div>
               </div>
               <div class="dog-boxes">
                  <div class="find-left">
                     <img src="<?php echo bloginfo('url'); ?>/wp-content/themes/pumpkin-astra/listing-images/Left.png" alt="">
                  </div>
                  <div class="find-right">
                     <img src="<?php echo bloginfo('url'); ?>/wp-content/themes/pumpkin-astra/listing-images/right.png" alt="">
                  </div>
               </div>
            </div>
         </div>
      </section>