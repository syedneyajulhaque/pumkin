<section id="mobile-show">
   <div class="container">
      <button type="button" class="accord" data-toggle="modal" data-target="#exampleModal">
      <span class="filter">Filters</span><span class="mfiltercount"></span> <span class="union"><img src="<?php echo bloginfo('url'); ?>/wp-content/themes/pumpkin-astra/listing-images/Union.svg" alt=""></span>
      </button>
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <div class="modal-body mng-alls no-marg">
                  <h3>Size</h3>
                  <div class="btn-group btn-group-toggle d-flex flex-md-row" data-toggle="buttons">
                     <label class="btn btn-primary custms">
                     <input class="fsize" type="checkbox" name="size[]" value="Small" autocomplete="on"> Small
                     </label>
                     <label class="btn btn-primary custms">
                     <input class="fsize" type="checkbox" name="size[]" value="Medium" autocomplete="on"> Medium
                     </label>
                     <label class="btn btn-primary custms">
                     <input class="fsize" type="checkbox" name="size[]" value="Large" autocomplete="on"> Large
                     </label>
                  </div>
               </div>
               <div class="modal-body mng-alls">
                  <h3>Shedding</h3>
                  <div class="tyay">
                     <label class="mmmcv">Low Shedding
                     <input class="shedding" type="checkbox" name="Shedding" value="true">
                     <span class="checkmark"></span>
                     </label>
                     <label class="mmmcv">Hypoallergenic
                     <input class="hypo" type="checkbox" name="Hypoallergenic" value="true">
                     <span class="checkmark"></span>
                     </label>
                  </div>
               </div>
               <div class="modal-body mng-alls">
                  <h3>Grooming Effort</h3>
                  <div class="btn-group btn-group-toggle d-flex flex-md-row" data-toggle="buttons">
                     <label class="btn btn-primary custms active">
                     <input class="grooming" type="checkbox" name="grooming[]" value="Easy"> Easy
                     </label>
                     <label class="btn btn-primary custms">
                     <input class="grooming" type="checkbox" name="grooming[]" value="Moderate"> Moderate
                     </label>
                     <label class="btn btn-primary custms">
                     <input class="grooming" type="checkbox" name="grooming[]" value="Lots of Work"> Lots of Work
                     </label>
                  </div>
               </div>
               <div class="modal-body mng-alls">
                  <h3>Exercise Needs</h3>
                  <div class="btn-group btn-group-toggle d-flex flex-md-row" data-toggle="buttons">
                     <label class="btn btn-primary custms active">
                     <input class="exercise" type="checkbox" name="exercise[]" value="Not So Much"> Not So Much
                     </label>
                     <label class="btn btn-primary custms">
                     <input class="exercise" type="checkbox" name="exercise[]" value="Moderate"> Moderate
                     </label>
                     <label class="btn btn-primary custms">
                     <input class="exercise" type="checkbox" name="exercise[]" value="A Lot"> A LOT
                     </label>
                  </div>
               </div>
               <div class="modal-body mng-alls">
                  <h3>Training Ability</h3>
                  <div class="btn-group btn-group-toggle d-flex flex-md-row" data-toggle="buttons">
                     <label class="btn btn-primary custms active">
                     <input class="training" type="checkbox" name="training[]" value="So-So"> So-So
                     </label>
                     <label class="btn btn-primary custms">
                     <input class="training" type="checkbox" name="training[]" value="Good"> Good
                     </label>
                     <label class="btn btn-primary custms">
                     <input class="training" type="checkbox" name="training[]" value="Pawesome"> Pawesome
                     </label>
                  </div>
               </div>
               <div class="modal-body mng-alls">
                  <h3>Pets & Kids</h3>
                  <div class="tyay">
                     <label class="mmmcv">Pet-Friendly
                     <input class="pet-friendly" type="checkbox" name="pet-friendly" value="">
                     <span class="checkmark"></span>
                     </label>
                     <label class="mmmcv">Kid-Friendly
                     <input class="kid-friendly" type="checkbox" name="kid-friendly" value="">
                     <span class="checkmark"></span>
                     </label>
                  </div>
               </div>
               <div class="modal-body mng-alls">
                  <p>
                     <button type="button" class="accordsss" data-toggle="collapse" data-target="#demo">
                        <span class="filter">Appearance Filters</span> 
                        <span class="chervo">
                           <a href="#">
                  <div class="fa fa-chevron-down rotate"></div></a>
                  </span>
                  </button>
                  <div id="demo" class="collapse">
                     <div class="white-box-new mng-this">
                        <div class="gooming-box">
                           <h4 class="g-effert">Coat Colors</h4>
                           <div class="btn-group btn-group-toggle d-flex  flex-md-row" data-toggle="buttons">
                              <label class="btn btn-primary custms">
                                 <div class="black customcb">
                                    <input class="colors" type="checkbox" name="colors" id="customcb4" value="Black">
                              <label class="inner" for="customcb4"></label>
                              <label class="outer" for="customcb4">Black</label>
                              </div>
                              </label>
                              <label class="btn btn-primary custms">
                                 <div class="cream customcb">
                                    <input class="colors" type="checkbox" name="colors" id="customcb5" value="Cream">
                              <label class="inner" for="customcb5"></label>
                              <label class="outer" for="customcb5">Cream</label>
                              </div>
                              </label>
                              <label class="btn btn-primary custms">
                                 <div class="red customcb">
                                    <input class="colors" type="checkbox" name="colors" id="customcb6" value="Red">
                              <label class="inner" for="customcb6"></label>
                              <label class="outer" for="customcb6">Red</label>
                              </div>
                              </label>
                           </div>
                           <div class="btn-group btn-group-toggle d-flex  flex-md-row" data-toggle="buttons">
                              <label class="btn btn-primary custms">
                                 <div class="blue customcb">
                                    <input class="colors" type="checkbox" name="colors" id="customcb7" value="Blue">
                              <label class="inner" for="customcb7"></label>
                              <label class="outer" for="customcb7">Blue</label>
                              </div>
                              </label>
                              <label class="btn btn-primary custms">
                                 <div class="gold customcb">
                                    <input class="colors" type="checkbox" name="colors" id="customcb8" value="Gold">
                              <label class="inner" for="customcb8"></label>
                              <label class="outer" for="customcb8">Gold</label>
                              </div>
                              </label>
                              <label class="btn btn-primary custms">
                                 <div class="white customcb">
                                    <input class="colors" type="checkbox" name="colors" id="customcb9" value="White">
                              <label class="inner" for="customcb9"></label>
                              <label class="outer" for="customcb9">White</label>
                              </div>
                              </label>
                           </div>
                           <div class="btn-group btn-group-toggle d-flex flex-md-row" data-toggle="buttons">
                              <label class="btn btn-primary custms">
                                 <div class="brown customcb">
                                    <input class="colors" type="checkbox" name="colors" id="customcb10" value="Brown">
                              <label class="inner" for="customcb10"></label>
                              <label class="outer" for="customcb10">Brown</label>
                              </div>
                              </label>
                              <label class="btn btn-primary custms">
                                 <div class="gray customcb">
                                    <input class="colors" type="checkbox" name="colors" id="customcb11" value="Grey">
                              <label class="inner" for="customcb11"></label>
                              <label class="outer" for="customcb11">Grey</label>
                              </div>
                              </label>
                              <label class="btn btn-primary custms">
                                 <div class="yellow customcb">
                                    <input class="colors" type="checkbox" name="colors" id="customcb12" value="Yellow">
                              <label class="inner" for="customcb12"></label>
                              <label class="outer" for="customcb12">Yellow</label>
                              </div>
                              </label>
                           </div>
                           <div class="tyay">
                              <div class="gooming-box">
                                 <h4 class="g-effert">Coat Type</h4>
                                 <label class="mmmcv">Long
                                 <input class="coat-type" type="checkbox" name="coattype[]" value="Long">
                                 <span class="checkmark"></span>
                                 </label>
                                 <label class="mmmcv">Medium
                                 <input class="coat-type" type="checkbox" name="coattype[]" value="Medium">
                                 <span class="checkmark"></span>
                                 </label>
                                 <label class="mmmcv">Short
                                 <input class="coat-type" type="checkbox" name="coattype[]" value="Short">
                                 <span class="checkmark"></span>
                                 </label>
                                 <label class="mmmcv">Hairless
                                 <input class="coat-type" type="checkbox" name="coattype[]" value="Hairless">
                                 <span class="checkmark"></span>
                                 </label>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  </p>
                  <p>
                     <button type="button" class="accordsss" data-toggle="collapse" data-target="#demo1">
                        <span class="filter">Characteristic Filters</span> 
                        <span class="chervo">
                           <a href="#">
                  <div class="fa fa-chevron-down rotate"></div></a>
                  </span>
                  </button>
                  <div id="demo1" class="collapse">
                     <div class="white-box-new">
                        <div class="gooming-box">
                           <h4 class="g-effert">Affection Level</h4>
                           <div class="btn-group btn-group-toggle d-flex flex-md-row" data-toggle="buttons">
                              <label class="btn btn-primary custms">
                              <input class="affection" type="checkbox" name="affection[]" value="Low"> Low
                              </label>
                              <label class="btn btn-primary custms">
                              <input class="affection" type="checkbox" name="affection[]" value="Medium"> Medium
                              </label>
                              <label class="btn btn-primary custms">
                              <input class="affection" type="checkbox" name="affection[]" value="Warm & Fuzzy">Warm & Fuzzy
                              </label>
                           </div>
                        </div>
                        <div class="gooming-box">
                           <h4 class="g-effert">Barking</h4>
                           <div class="btn-group btn-group-toggle d-flex flex-md-row" data-toggle="buttons">
                              <label class="btn btn-primary custms">
                              <input class="barking" type="checkbox" name="barking[]" value="A Little"> A Little
                              </label>
                              <label class="btn btn-primary custms">
                              <input class="barking" type="checkbox" name="barking[]" value="A Fair Amount"> A Fair Amount
                              </label>
                              <label class="btn btn-primary custms">
                              <input class="barking" type="checkbox" name="barking[]" value="A Bark-load"> A Bark-load
                              </label>
                           </div>
                        </div>
                        <div class="gooming-box">
                           <h4 class="g-effert">Intelligence</h4>
                           <div class="btn-group btn-group-toggle d-flex flex-md-row" data-toggle="buttons">
                              <label class="btn btn-primary custms">
                              <input class="intelligence" type="checkbox" name="intelligence[]" value="Average"> Average
                              </label>
                              <label class="btn btn-primary custms">
                              <input class="intelligence" type="checkbox" name="intelligence[]" value="High"> High
                              </label>
                              <label class="btn btn-primary custms">
                              <input class="intelligence" type="checkbox" name="intelligence[]" value="Off the Charts"> Off the Charts
                              </label>
                           </div>
                        </div>
                     </div>
                  </div>
                  </p>
               </div>
               <?php 
                  $args = array(
                  'post_type' =>  'page',
                  'posts_per_page' => -1,
                  'post__not_in' => array( 2053, 5125,5165 ),
                  );
                    $posts_array = get_posts( $args );
                    $total_pages = count($posts_array);
                  ?>
               <div class="modal-footer">
                  <span class="brdssss">(<span class="breedcount"><?php echo $total_pages; ?></span> Breeds)</span>
                  <button type="button" class="closeses" href="javascript:void()" data-dismiss="modal">Clear All</button>
                  <button type="button" class="save-btn" id="filtersubmit">Apply</button>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>