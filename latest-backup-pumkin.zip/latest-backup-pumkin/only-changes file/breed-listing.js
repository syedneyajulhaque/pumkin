    jQuery( document ).ready(function() {
   	 	jQuery("#breediterableform").submit(function(event) {		
   var email = jQuery('#breed-input').val();
   //alert(email);
     /* stop form from submitting normally */
     event.preventDefault();
   	jQuery.ajax({
       type: 'POST',
       url: 'https://links.iterable.com/lists/publicAddSubscriberForm?publicIdString=341a0959-7e7f-4ab6-b967-903337fd46ae',
       data: {
           'email': email 
       },
       dataType: 'html',
       success: function(response) { 
   	 jQuery('#breedresponseDiv').html(jQuery(response).find('.post-subscribe-form h4').html());
   		
       },
       error: function(errorThrown) {
           jQuery('#breedresponseDiv').html("Something Went Wrong");
       },
   });
   	});
  
        jQuery('.pets').owlCarousel({
         loop:true,
         margin:30,
         nav:true,
         dots:true,
         responsive:{
         0:{
             items:1
         },
         600:{
             items:2
         },
         1000:{
             items:3
         }
         }
         });
     
         jQuery(document).on('click', '.expl-btnss .dropdown-menu', function (e) {
           e.stopPropagation();
         });
     
jQuery('#facet').typeToFilter({
  zeroResultMessage: 'This breed isn’t available yet, but it’s coming soon! In the meantime, you can use our filters to find another pawesome match.'
});


    jQuery(".my-list li").hide(); 
 
    /* filter products */
    jQuery("#search-breeds").on("keyup click input", function () {
		/*$("#search-breeds").LoadingOverlay("show", {
			    background  : "rgba(165, 190, 100, 0)"
		}); */
		if( $(".qsearchlisting input").val().length === 0 ) {
			$(".qsearchlisting i").removeClass('fa-close');
		$(".qsearchlisting i").addClass('fa-search');
	}
 
		
        if (this.value.length > 2) {
			//$("#search-breeds").LoadingOverlay("show");
            jQuery(".my-list li").removeClass("match").hide().filter(function () {
                return jQuery(this).text().toLowerCase().indexOf($(".my-list").val().toLowerCase()) != -1;
            }).addClass("match").show();
           // highlight(this.value);
            jQuery(".my-list").fadeIn( "slow" );
			$(".qsearchlisting i").removeClass('fa-search');
			$(".qsearchlisting i").addClass('fa-close');
			//$("#search-breeds").LoadingOverlay("hide");
			jQuery(".qsearchlisting i").click(function(){
	
 $(".qsearchlisting i").removeClass('fa-close');
$(".qsearchlisting i").addClass('fa-search');
$(".qsearchlisting input").val('');
jQuery(".my-list").hide();
});
        }
        else {
            jQuery(".my-list, .my-list li").removeClass("match").hide();
        }
		
    });
	
 
         jQuery(".rotate").click(function(){
 jQuery(this).toggleClass("down"); 
});
     
         jQuery('.submitfilter').click(function(){
           //console.log('clicked')
          jQuery('.expl-btnss .dropdown .dropdown-menu').removeClass('show')
         });
		 jQuery('.desktopclose').click(function(){
           //console.log('clicked')
          jQuery('.expl-btnss .dropdown .dropdown-menu').removeClass('show')
         });
		});
		

		


var $checkboxes1 = $('.filter1 input[type="checkbox"]');        
    $checkboxes1.change(function(){
        var countCheckedCheckboxes = $checkboxes1.filter(':checked').length;
        if(countCheckedCheckboxes != ''){
       jQuery(".filter1 .submitfilter").attr("disabled",false);
	    $('.filter1 .submitfilter').addClass("active");
		$(".filtercount").html("("+countCheckedCheckboxes+")");
		
    }else{
		jQuery(".filter1 .submitfilter").attr("disabled",true);
		 $('.filter1 .submitfilter').removeClass("active");
		  $(".filtercount").html("");
		    $('.acfilter1').removeClass("active");
	}
	});


var $checkboxes2 = $('.filter2 input[type="checkbox"]');        
    $checkboxes2.change(function(){
        var countCheckedCheckboxes = $checkboxes2.filter(':checked').length;
        if(countCheckedCheckboxes != ''){
       jQuery(".filter2 .submitfilter").attr("disabled",false);
	    $('.filter2 .submitfilter').addClass("active");
		$(".filtercount2").html("("+countCheckedCheckboxes+")");
    }else{
		jQuery(".filter2 .submitfilter").attr("disabled",true);
		 $('.filter2 .submitfilter').removeClass("active");
		 $(".filtercount2").html("");
		 $('.acfilter2').removeClass("active");
	}
	});
	
	var $checkboxes3 = $('.filter3 input[type="checkbox"]');        
    $checkboxes3.change(function(){
        var countCheckedCheckboxes = $checkboxes3.filter(':checked').length;
        if(countCheckedCheckboxes != ''){
       jQuery(".filter3 .submitfilter").attr("disabled",false);
	    $('.filter3 .submitfilter').addClass("active");
		$(".filtercount3").html("("+countCheckedCheckboxes+")");
    }else{
		jQuery(".filter3 .submitfilter").attr("disabled",true);
		 $('.filter3 .submitfilter').removeClass("active");
		 $(".filtercount3").html("");
		 $('.acfilter3').removeClass("active");
	}
	});
	
	var $checkboxes4 = $('.filter4 input[type="checkbox"]');        
    $checkboxes4.change(function(){
        var countCheckedCheckboxes = $checkboxes4.filter(':checked').length;
        if(countCheckedCheckboxes != ''){
       jQuery(".filter4 .submitfilter").attr("disabled",false);
	    $('.filter4 .submitfilter').addClass("active");
		$(".filtercount4").html("("+countCheckedCheckboxes+")");
    }else{
		jQuery(".filter4 .submitfilter").attr("disabled",true);
		 $('.filter4 .submitfilter').removeClass("active");
		 $(".filtercount4").html("");
		 $('.acfilter4').removeClass("active");
	}
	});
	
	var $checkboxes5 = $('.filter5 input[type="checkbox"]');        
    $checkboxes5.change(function(){
        var countCheckedCheckboxes = $checkboxes5.filter(':checked').length;
        if(countCheckedCheckboxes != ''){
       jQuery(".filter5 .submitfilter").attr("disabled",false);
	    $('.filter5 .submitfilter').addClass("active");
		$(".filtercount5").html("("+countCheckedCheckboxes+")");
    }else{
		jQuery(".filter5 .submitfilter").attr("disabled",true);
		 $('.filter5 .submitfilter').removeClass("active");
		 $(".filtercount5").html("");
		 $('.acfilter5').removeClass("active");
	}
	});
	
	var $checkboxes6 = $('.filter6 input[type="checkbox"]');        
    $checkboxes6.change(function(){
        var countCheckedCheckboxes = $checkboxes6.filter(':checked').length;
        if(countCheckedCheckboxes != ''){
       jQuery(".filter6 .submitfilter").attr("disabled",false);
	    $('.filter6 .submitfilter').addClass("active");
		$(".filtercount6").html("("+countCheckedCheckboxes+")");
    }else{
		jQuery(".filter6 .submitfilter").attr("disabled",true);
		 $('.filter6 .submitfilter').removeClass("active");
		 $(".filtercount6").html("");
		 $('.acfilter6').removeClass("active");
	}
	});
	
	var $Mcheckboxes = $('#exampleModal input[type="checkbox"]');        
    $Mcheckboxes.change(function(){
        var McountCheckedCheckboxes = $Mcheckboxes.filter(':checked').length;
        if(McountCheckedCheckboxes != ''){
		$(".mfiltercount").html("("+McountCheckedCheckboxes+")");
    }else{
		
		 $(".mfiltercount").html("");
	}
	});
	
	
	jQuery(".filter1 .submitfilter").on("click",function(){ // When btn is pressed.
        $('.acfilter1').addClass("active");
});
jQuery(".filter2 .submitfilter").on("click",function(){ // When btn is pressed.
        $('.acfilter2').addClass("active");
});
jQuery(".filter3 .submitfilter").on("click",function(){ // When btn is pressed.
        $('.acfilter3').addClass("active");
});
jQuery(".filter4 .submitfilter").on("click",function(){ // When btn is pressed.
        $('.acfilter4').addClass("active");
});
jQuery(".filter5 .submitfilter").on("click",function(){ // When btn is pressed.
        $('.acfilter5').addClass("active");
});
jQuery(".filter6 .submitfilter").on("click",function(){ // When btn is pressed.
        $('.acfilter6').addClass("active");
});
 
var pageNumber = 1;
function filter_breeds(){
	//jQuery(".defaultlisting").hide();
	//jQuery("#more_posts").hide();
	//$('.sizefilter').addClass("active");
   var ajaxurl = "https://pumpkin.fundflu.com/wp-content/themes/pumpkin-astra/ajax/breeds.php";
    var sizet = $('.fsize:checked').map(function () {
         return this.value;
     }).get();
	  var shedding = $('.shedding').is(':checked');
	  var hypo = $('.hypo').is(':checked');
	  var pfriendly = $('.pet-friendly').is(':checked');
	   var kfriendly = $('.kid-friendly').is(':checked');
	  var grooming = $('.grooming:checked').map(function () {
         return this.value;
     }).get();
	 var exercise = $('.exercise:checked').map(function () {
         return this.value;
     }).get();
	 var training = $('.training:checked').map(function () {
         return this.value;
     }).get();
	 var colors = $('.colors:checked').map(function () {
         return this.value;
     }).get();
	 var coattype = $('.coat-type:checked').map(function () {
         return this.value;
     }).get();
	 var affection = $('.affection:checked').map(function () {
         return this.value;
     }).get();
	 var barking = $('.barking:checked').map(function () {
         return this.value;
     }).get();
	 var intelligence = $('.intelligence:checked').map(function () {
         return this.value;
     }).get();
	 
	 var selectfilter = $( "#myselect" ).val();
	 //alert(selectfilter);
    jQuery.ajax({
        type: "POST",
		url: ajaxurl,
       data: {size : sizet, grooming: grooming, shedding: shedding, hypo: hypo, exercise: exercise, training: training, pfriendly: pfriendly, kfriendly: kfriendly, colors: colors, coattype: coattype, affection: affection, barking: barking,intelligence: intelligence, selectfilter: selectfilter, page : pageNumber },
		beforeSend: function() {
			//alert(countCheckedCheckboxes);
			//var szln = sizet.length;
		 //$(".filtercount").html("( "+szln+" )");
		 $('#exampleModal').modal('hide');
		$.LoadingOverlay("show", {
			image       : "",
			background              : "rgba(255, 255, 255, 0.8)",
			fontawesome : "fa fa-circle-o-notch fa-spin",
			fontawesomeColor        : "#4A6BFF"  
		});
        },
        success: function(data){
//window.history.pushState("Details", "Title", "<?php echo bloginfo('url'); ?>/breed-staging/?filter="+sizet);
			 if(data == "-1"){
        jQuery('#more_posts').hide();
		 //$("#results").append(msg);
		  $("#results").html("<div class='row'><h4 class='nreslt'>Ruh-Roh!</h4><p class='nres3'>We couldn't find any breeds that fit your exact search criteria. Check out these close matches, or <a href='#'>clear your filters</a> and try modifying your search.</p></div><div id='res2' class='row'></div><button class='loads-more-posts' id='no-results-load'>Load More</button>");
				  jQuery("#no-results-load").on("click",function(){ // When btn is pressed.
			   jQuery("#no-results-load").attr("disabled",true); // Disable the button, temp.
				//alert();
				load_no_results_posts();
				
			});

		  var pgno = 1;
		  $.ajax({
                type: "post",
                url: "https://pumpkin.fundflu.com/wp-content/themes/pumpkin-astra/ajax/no-results.php",
                data: {page : pgno},
				beforeSend: function() {
				$.LoadingOverlay("show", {
					image       : "",
			background              : "rgba(255, 255, 255, 0.8)",
			fontawesome : "fa fa-circle-o-notch fa-spin",
			fontawesomeColor        : "#4A6BFF"  
				});
				},
                success: function (data) {
				$("#res2").html(data);
				$.LoadingOverlay("hide");
                }
				 });
			 }else{
				 $("#results").html(data);
				 //jQuery(".defaultlisting").hide();
				 //$("#results").append(data);
			 }
        },
		error: function(xhr) { // if error occured
        alert("Error occured.please try again");
        //$(placeholder).append(xhr.statusText + xhr.responseText);
        //$(placeholder).removeClass('loading');
    },
    complete: function() {
     $.LoadingOverlay("hide");
	  jQuery("#more_posts").attr("disabled",false); 
	  var numItems = $('.count').length;
			//console.log(data);
			var breed_result_count = $('.breed_result_count').html();
			//alert(breed_result_count);
			if(breed_result_count == numItems){
				jQuery("#more_posts").hide();
			}
			if(breed_result_count != undefined){
		jQuery(".breedcount").html(breed_result_count);	
			}else{ 
            jQuery(".breedcount").html("0");	
			}			
			//alert(breed_result_count);
    },

    });
    return false;
	
}


var pageNumber = 1;
	var msg = "<h3>No More Breeds Found</h3>";
var ajaxurl = "https://pumpkin.fundflu.com/wp-content/themes/pumpkin-astra/ajax/breeds.php";
function load_posts(){
   pageNumber++;
    var sizet = $('.fsize:checked').map(function () {
         return this.value;
     }).get();
	 

    jQuery.ajax({
        type: "POST",
		url: ajaxurl,
        data: {page : pageNumber},
		beforeSend: function() {
		$.LoadingOverlay("show", {
			image       : "",
			background              : "rgba(255, 255, 255, 0.8)",
			fontawesome : "fa fa-circle-o-notch fa-spin",
			fontawesomeColor        : "#4A6BFF"  
		});
        },
        success: function(data){
			//window.history.pushState("Details", "Title", "<?php echo bloginfo('url'); ?>/breed-staging/?page="+pageNumber);
			 if(data == "-1"){
        jQuery('#more_posts').hide();
		 //$("#results").append(msg);
			 }else{
				 $("#results").append(data);
			 }
        },
		error: function(xhr) { // if error occured
        alert("Error occured.please try again");
        //$(placeholder).append(xhr.statusText + xhr.responseText);
        //$(placeholder).removeClass('loading');
    },
    complete: function() {
     $.LoadingOverlay("hide");
	  jQuery("#more_posts").attr("disabled",false); 
    },

    });
    return false;
}


	
var pgno= 1;
	function load_no_results_posts(){
        pgno++;
     $.ajax({
                type: "post",
                url: "https://pumpkin.fundflu.com/wp-content/themes/pumpkin-astra/ajax/no-results.php",
                data: {page : pgno},
				beforeSend: function() {
				$.LoadingOverlay("show", {
					image       : "",
			background              : "rgba(255, 255, 255, 0.8)",
			fontawesome : "fa fa-circle-o-notch fa-spin",
			fontawesomeColor        : "#4A6BFF"  
				});
				},
                success: function (data) {
				if(data == "-1"){
        jQuery('#no-results-load').hide();
			 }else{
				 $("#res2").append(data);
			 }
                },
				error: function(xhr) { // if error occured
				 alert("Error occured.please try again");
			 
			},
				complete: function() {
					//pgno++;
             $.LoadingOverlay("hide");
			jQuery("#no-results-load").attr("disabled",false); 
    },
				 });
    return false;
}

jQuery("#more_posts").on("click",function(){ // When btn is pressed.
   jQuery("#more_posts").attr("disabled",true); // Disable the button, temp.
    //load_posts();
	pageNumber++;
	  filter_breeds();
	  
});


jQuery("#filtersubmit").on("click",function(){ // When btn is pressed.
   // jQuery("#more_posts").attr("disabled",true); // Disable the button, temp.
    //e.preventDefault();
    filter_breeds();
});

jQuery(".clrs a").on("click",function(){ // When btn is pressed.
   location.reload(true);
});
jQuery(".closeses").on("click",function(){ // When btn is pressed.
   location.reload(true);
});

jQuery('#myselect').on('change', function() {
  //alert( this.value );
  filter_breeds();
});
//$( "#myselect" ).val();




// this js for select box //


$(document).ready(function(){
	$('.justselect').each(function(){
		$(this).wrap('<div class="justselect-wrapper">');
	
		var justselectUL = document.createElement( "ul" );
			justselectUL.className = "justselect-list";
			
		var justselectTitle = document.createElement( "div" ); 	
			justselectTitle.className = "justselect-title";
			
		var	select = $(this).parent(),
			option = $(this).find($('option'));
			
			select.append(justselectTitle, justselectUL);		
			
			for (i = 0; i< option.length; i++) {
				var justselectLI = document.createElement( "li" );
				    justselectUL.append(justselectLI),
				    justselectLI_option = select.find($('.justselect-list li'));
				    
				    justselectLI_option.eq(i).text(option.eq(i).text());
				    
				    if (option.eq(i).attr('selected')) {
					    justselectLI_option.eq(i).addClass('selected');
					    select.find($('.justselect-title')).text(justselectLI_option.eq(i).text());
				    }
				    
				    justselectLI_option.click(function(){
					    $(this).addClass('selected').siblings().removeAttr('class');
					    var index = $(this).index();
					    
					    select.find($('.justselect-list')).fadeOut();
					    $('.justselect-body-overlay').remove();	
					    
					    option.eq(index).attr("selected", true).siblings().removeAttr("selected");
					    select.find($('.justselect-title')).text($(this).text());
				    });			    
			}
			
		select.find($('.justselect-title')).click(function(){
			select.find($('.justselect-list')).fadeToggle();
			
		    var bodyOverlay = document.createElement( "div" ); 
		    	bodyOverlay.className = "justselect-body-overlay";
				$('body').prepend(bodyOverlay);		
	
				$('.justselect-body-overlay').click(function(){
					select.find($('.justselect-list')).fadeToggle();
					$('.justselect-body-overlay').remove();	
				});						
		});			
	});	
});

