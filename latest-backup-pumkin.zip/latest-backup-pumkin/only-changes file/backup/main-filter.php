<div class="explore-box">
         <h2>Explore Breeds by:</h2>
      </div>
<form action="#" onsubmit="filter_breeds();return false">
         <div class="row position-relative">
		 
            <div class="expl-btnss">
               <div class="dropdown">
                  <button class="btn btn-secondary dropdown-toggle acfilter1" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Size <span class="filtercount"></span></a>
                  </button>
                  <div class="dropdown-menu filter1" aria-labelledby="dropdownMenuButton">
                     <div class="btn-group btn-group-toggle d-flex flex-column flex-md-row" data-toggle="buttons">
                        <label class="btn btn-primary custms active">
                        <input class="fsize" type="checkbox" name="size[]" value="Small" autocomplete="on"> Small
                        </label>
                        <label class="btn btn-primary custms">
                        <input class="fsize" type="checkbox" name="size[]" value="Medium" autocomplete="on"> Medium
                        </label>
                        <label class="btn btn-primary custms">
                        <input class="fsize" type="checkbox" name="size[]" value="Large" autocomplete="on"> Large
                        </label>
                     </div>
                     <div class="buttonsss">
                        <span class="clrs"><a href="javascript:void()">Clear</a></span>
                        <span class="apy"><input class="submitfilter" id="filtersubmit" type="submit" name="submit" value="Apply" disabled></span>
                     </div>
                  </div>
               </div>
            </div>
            <div class="expl-btnss">
               <div class="dropdown">
                  <button class="btn btn-secondary dropdown-toggle acfilter2" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Shedding <span class="filtercount2"></span>
                  </button>
                  <div class="dropdown-menu filter2" aria-labelledby="dropdownMenuButton">
                     <div class="tyay">
                        <label class="mmmcv">Low Shedding
                         <input class="shedding" type="checkbox" name="Shedding" value="true">
                        <span class="checkmark"></span>
                        </label>
                        <label class="mmmcv">Hypoallergenic
                         <input class="hypo" type="checkbox" name="Hypoallergenic" value="true">
                        <span class="checkmark"></span>
                        </label>
                     </div>
                     <h4 class="g-effert">Grooming Effort</h4>
                     <div class="btn-group btn-group-toggle d-flex flex-column flex-md-row" data-toggle="buttons">
                        <label class="btn btn-primary custms active">
                        <input class="grooming" type="checkbox" name="grooming[]" value="Easy"> Easy
                        </label>
                        <label class="btn btn-primary custms">
                        <input class="grooming" type="checkbox" name="grooming[]" value="Moderate"> Moderate
                        </label>
                        <label class="btn btn-primary custms">
                       <input class="grooming" type="checkbox" name="grooming[]" value="Lots of Work"> Lots of Work
                        </label>
                     </div>
                     <div class="buttonsss">
                        <span class="clrs"><a href="javascript:void()">Clear</a></span>
                       <span class="apy"><input class="submitfilter" id="filtersubmit" type="submit" name="submit" value="Apply" disabled></span>
                     </div>
                  </div>
               </div>
            </div>
            <div class="expl-btnss">
               <div class="dropdown">
                  <button class="btn btn-secondary dropdown-toggle acfilter3" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Exercise Needs <span class="filtercount3"></span>
                  </button>
                  <div class="dropdown-menu filter3" aria-labelledby="dropdownMenuButton">
                     <div class="btn-group btn-group-toggle d-flex flex-column flex-md-row" data-toggle="buttons">
                        <label class="btn btn-primary custms active">
                       <input class="exercise" type="checkbox" name="exercise[]" value="Not So Much"> Not So Much
                        </label>
                        <label class="btn btn-primary custms">
                        <input class="exercise" type="checkbox" name="exercise[]" value="Moderate"> Moderate
                        </label>
                        <label class="btn btn-primary custms">
                        <input class="exercise" type="checkbox" name="exercise[]" value="A Lot"> A LOT
                        </label>
                     </div>
                     <div class="buttonsss">
                        <span class="clrs"><a href="javascript:void()">Clear</a></span>
                       <span class="apy"><input class="submitfilter" id="filtersubmit" type="submit" name="submit" value="Apply" disabled></span>
                     </div>
                  </div>
               </div>
            </div>
            <div class="expl-btnss">
               <div class="dropdown">
                  <button class="btn btn-secondary dropdown-toggle acfilter4" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Training Ability <span class="filtercount4"></span>
                  </button>
                  <div class="dropdown-menu filter4" aria-labelledby="dropdownMenuButton">
                     <div class="btn-group btn-group-toggle d-flex flex-column flex-md-row" data-toggle="buttons">
                        <label class="btn btn-primary custms active">
                        <input class="training" type="checkbox" name="training[]" value="So-So"> So-So
                        </label>
                        <label class="btn btn-primary custms">
                        <input class="training" type="checkbox" name="training[]" value="Good"> Good
                        </label>
                        <label class="btn btn-primary custms">
                        <input class="training" type="checkbox" name="training[]" value="Pawesome"> Pawesome
                        </label>
                     </div>
                     <div class="buttonsss">
                        <span class="clrs"><a href="javascript:void()">Clear</a></span>
                        <span class="apy"><input class="submitfilter" id="filtersubmit" type="submit" name="submit" value="Apply" disabled></span>
                     </div>
                  </div>
               </div>
            </div>
            <div class="expl-btnss">
               <div class="dropdown">
                  <button class="btn btn-secondary dropdown-toggle acfilter5" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Pets & Kids <span class="filtercount5"></span>
                  </button>
                  <div class="dropdown-menu filter5" aria-labelledby="dropdownMenuButton">
                     <div class="tyay">
                        <label class="mmmcv">Pet-Friendly
                         <input class="pet-friendly" type="checkbox" name="pet-friendly" value="">
                        <span class="checkmark"></span>
                        </label>
                        <label class="mmmcv">Kid-Friendly
                         <input class="kid-friendly" type="checkbox" name="kid-friendly" value="">
                        <span class="checkmark"></span>
                        </label>
                     </div>
                     <div class="buttonsss">
                        <span class="clrs"><a href="javascript:void()">Clear</a></span>
                       <span class="apy"><input class="submitfilter" id="filtersubmit" type="submit" name="submit" value="Apply" disabled></span>
                     </div>
                  </div>
               </div>
            </div>
            <div class="expl-btnss right-tex">
               <div class="dropdown">
                  <button class="btn btn-secondary dropdown-toggle acfilter6" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  More Filters <span class="filtercount6"></span>
                  </button>
                  <div class="dropdown-menu filter6" aria-labelledby="dropdownMenuButton">
                     <div class="gfgj">
					 <button type="button" class="close desktopclose" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
            <div class="row">
               <div class="col-lg-6 col-sm-6 col-12">
                  <div class="white-box-new mng-this">
                     <h3>Appearance</h3>
                     <div class="gooming-box">
                        <h4 class="g-effert">Coat Colors</h4>
                        <div class="btn-group btn-group-toggle d-flex flex-column flex-md-row" data-toggle="buttons">
                           <label class="btn btn-primary custms">
                              <div class="black customcb">
								  <input class="colors" type="checkbox" name="colors" id="customcb4" value="Black">
                           <label class="inner" for="customcb4"></label>
                           <label class="outer" for="customcb4">Black</label>
                           </div>
                           </label>
                           <label class="btn btn-primary custms">
                              <div class="cream customcb">
								<input class="colors" type="checkbox" name="colors" id="customcb5" value="Cream">
                           <label class="inner" for="customcb5"></label>
                           <label class="outer" for="customcb5">Cream</label>
                           </div>
                           </label>
                           <label class="btn btn-primary custms">
                             
                              <div class="red customcb">
							<input class="colors" type="checkbox" name="colors" id="customcb6" value="Red">
                           <label class="inner" for="customcb6"></label>
                           <label class="outer" for="customcb6">Red</label>
                           </div>
                           </label>
                        </div>
                        <div class="btn-group btn-group-toggle d-flex flex-column flex-md-row" data-toggle="buttons">
						
                           <label class="btn btn-primary custms">
                            
                              <div class="blue customcb">
                                 <input class="colors" type="checkbox" name="colors" id="customcb7" value="Blue">
                           <label class="inner" for="customcb7"></label>
                           <label class="outer" for="customcb7">Blue</label>
                           </div>
                           </label>
                           <label class="btn btn-primary custms">
                            
                              <div class="gold customcb">
                                 <input class="colors" type="checkbox" name="colors" id="customcb8" value="Gold">
                           <label class="inner" for="customcb8"></label>
                           <label class="outer" for="customcb8">Gold</label>
                           </div>
                           </label>
                           <label class="btn btn-primary custms">
                            
                              <div class="white customcb">
                                 <input class="colors" type="checkbox" name="colors" id="customcb9" value="White">
                           <label class="inner" for="customcb9"></label>
                           <label class="outer" for="customcb9">White</label>
                           </div>
                           </label>
						   
                        </div>
                        <div class="btn-group btn-group-toggle d-flex flex-column flex-md-row" data-toggle="buttons">
                           <label class="btn btn-primary custms">
                             
                              <div class="brown customcb">
                                <input class="colors" type="checkbox" name="colors" id="customcb10" value="Brown">
                           <label class="inner" for="customcb10"></label>
                           <label class="outer" for="customcb10">Brown</label>
                           </div>
                           </label>
                           <label class="btn btn-primary custms">
                             
                              <div class="gray customcb">
                                 <input class="colors" type="checkbox" name="colors" id="customcb11" value="Grey">
                           <label class="inner" for="customcb11"></label>
                           <label class="outer" for="customcb11">Grey</label>
                           </div>
                           </label>
                           <label class="btn btn-primary custms">
                             
                              <div class="yellow customcb">
                                 <input class="colors" type="checkbox" name="colors" id="customcb12" value="Yellow">
                           <label class="inner" for="customcb12"></label>
                           <label class="outer" for="customcb12">Yellow</label>
                           </div>
                           </label>
                        </div>
                        <div class="tyay">
                           <div class="gooming-box">
                              <h4 class="g-effert">Coat Type</h4>
                              <label class="mmmcv">Long
                              <input class="coat-type" type="checkbox" name="coattype[]" value="Long">
                              <span class="checkmark"></span>
                              </label>
                              <label class="mmmcv">Medium
                             <input class="coat-type" type="checkbox" name="coattype[]" value="Medium">
                              <span class="checkmark"></span>
                              </label>
                              <label class="mmmcv">Short
                             <input class="coat-type" type="checkbox" name="coattype[]" value="Short">
                              <span class="checkmark"></span>
                              </label>
                              <label class="mmmcv">Hairless
                              <input class="coat-type" type="checkbox" name="coattype[]" value="Hairless">
                              <span class="checkmark"></span>
                              </label>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-sm-6 col-12">
                  <div class="white-box-new">
                     <h3>Characteristics</h3>
                     <div class="gooming-box">
                        <h4 class="g-effert">Affection Level</h4>
                        <div class="btn-group btn-group-toggle d-flex flex-column flex-md-row" data-toggle="buttons">
                           <label class="btn btn-primary custms">
                          <input class="affection" type="checkbox" name="affection[]" value="Low"> Low
                           </label>
                           <label class="btn btn-primary custms">
                           <input class="affection" type="checkbox" name="affection[]" value="Medium"> Medium
                           </label>
                           <label class="btn btn-primary custms">
                          <input class="affection" type="checkbox" name="affection[]" value="Warm & Fuzzy">Warm & Fuzzy
                           </label>
                        </div>
                     </div>
                     <div class="gooming-box">
                        <h4 class="g-effert">Barking</h4>
                        <div class="btn-group btn-group-toggle d-flex flex-column flex-md-row" data-toggle="buttons">
                           <label class="btn btn-primary custms">
                          <input class="barking" type="checkbox" name="barking[]" value="A Little"> A Little
                           </label>
                           <label class="btn btn-primary custms">
                           <input class="barking" type="checkbox" name="barking[]" value="A Fair Amount"> A Fair Amount
                           </label>
                           <label class="btn btn-primary custms">
                            <input class="barking" type="checkbox" name="barking[]" value="A Bark-load"> A Bark-load
                           </label>
                        </div>
                     </div>
                     <div class="gooming-box">
                        <h4 class="g-effert">Intelligence</h4>
                        <div class="btn-group btn-group-toggle d-flex flex-column flex-md-row" data-toggle="buttons">
                           <label class="btn btn-primary custms">
                          <input class="intelligence" type="checkbox" name="intelligence[]" value="Average"> Average
                           </label>
                           <label class="btn btn-primary custms">
                           <input class="intelligence" type="checkbox" name="intelligence[]" value="High"> High
                           </label>
                           <label class="btn btn-primary custms">
                           <input class="intelligence" type="checkbox" name="intelligence[]" value="Off the Charts"> Off the Charts
                           </label>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

               <div class="buttonsss">
                  <span class="clrs"><a href="javascript:void()">Clear</a></span>
                 <span class="apy"><input class="submitfilter" id="filtersubmit" type="submit" name="submit" value="Apply" disabled></span>
               </div>
         </div>
                  </div>
               </div>
            </div>
         </div>
      </form>
	  
	  <?php // Get total number of pages published
	//$count_pages = wp_count_posts('page');
	//$total_pages = $count_pages->publish;
	$args = array(
		'post_type' =>  'page',
		'posts_per_page' => -1,
		'post__not_in' => array( 2053, 5125,5165 ),
		);
   $posts_array = get_posts( $args );
   $total_pages = count($posts_array);
?>

   <div class="row">
            <div class="col-lg-12 col-sm-6 col-12">
               <div class="sorting">
                  <span class="wddw">(<span class="breedcount"><?php echo $total_pages; ?></span> Breed Results)</span><span class="sort">Sort By:</span>
                  <!-- <span class="popur">Popularity</span>-->
				   <select id="myselect">
    <option value="popularity">Popularity</option>
    <option value="atoz">A-Z</option>
</select>
                 
            </div>
         </div>

   </div>
   
